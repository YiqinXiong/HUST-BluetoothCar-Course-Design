/*
 * $File: vga.h
 * $Date: Fri Dec 13 23:55:56 2013 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#ifndef __HEADER_VGA__
#define __HEADER_VGA__

void vga_init();
void vga_redraw();
void vga_putch(int ch);

#endif // __HEADER_VGA__

