#ifndef __KIO_H__
#define __KIO_H__

#include <console.h>

#define kcons_putc cons_putc
#define kcons_getc cons_getc

#endif
